
package registropaises;
import java.util.ArrayList;
public class Registrar {
	ArrayList<Pais> paises;
	public Registrar(){
		paises = new ArrayList<>();
	}
	public void anhadirPais(Pais pais){
		paises.add(pais);
	}
}
