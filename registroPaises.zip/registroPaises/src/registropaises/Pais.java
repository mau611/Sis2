package registropaises;

public class Pais {
	String Nombre;
	int Codigo;
	String Idioma;
	public Pais(String Nombre, int Codigo, String Idioma){
		this.Nombre= Nombre;
		this.Codigo = Codigo;
		this.Idioma = Idioma;
	}
	public String getNombre(){
		return Nombre;
	}
}
