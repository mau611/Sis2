/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Registro;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author ASUS PC
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        String cod,nom,leng,paisS;
        String[] p;
        ArrayList<Pais> a=new ArrayList<>();
        FileReader f;
        File fl = new File("src/Registro/registro.txt");
        if(fl.exists()){
            f = new FileReader(fl);
            BufferedReader br = new BufferedReader(f);
            while((paisS=br.readLine())!=null){
                p=paisS.split(" ");
                Pais pais=new Pais(p[0],p[1],p[2]);
                a.add(pais);
            }
        }else{
            BufferedWriter bw;
            bw = new BufferedWriter(new FileWriter(fl));
            bw.close();
        }
        Ventana V = new Ventana();      
        V.setVisible(true);     
        
    }
    
}