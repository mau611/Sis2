/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Registro;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Agregar extends JFrame implements ActionListener {

    private JLabel nom;           
    private JTextField nomTF;        
    private JButton boton;
    private JLabel cod;           
    private JTextField codTF;        
    private JButton boton1;
    private JLabel leng;           
    private JTextField lengTF;  
    private String paises="";
    public Agregar() throws IOException {
        super();                    
        configurarVentana();        
        inicializarComponentes();   
    }

    private void configurarVentana() throws FileNotFoundException, IOException {
        this.setTitle("Esta Es Una Ventana");                   
        this.setSize(450, 310);                                 
        this.setLocationRelativeTo(null);                       
        this.setLayout(null);                                   
        this.setResizable(false);                               
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        File fl = new File("src/Registro/registro.txt");
        FileReader f = new FileReader(fl);
        BufferedReader br = new BufferedReader(f);
        String paisS="";
            while((paisS=br.readLine())!=null){
                paises=paises.concat(paisS.toLowerCase().trim()).concat("\n");
            }
    }

    private void inicializarComponentes() {
        cod = new JLabel();
        nom = new JLabel();
        leng = new JLabel();
        boton = new JButton(); 
        codTF = new JTextField();
        nomTF = new JTextField();
        lengTF = new JTextField();
        cod.setText("codigo");
        cod.setBounds(30, 20,70, 25);
        this.add(cod);
        nom.setText("nombre");
        nom.setBounds(150, 20, 70, 25);
        this.add(nom);
        leng.setText("lengua");       
        leng.setBounds(270, 20, 70, 25);
        this.add(leng);
        codTF.setBounds(30, 70,100, 25);
        this.add(codTF);
        nomTF.setBounds(150, 70, 100, 25);
        this.add(nomTF);       
        lengTF.setBounds(270, 70, 100, 25);
        this.add(lengTF);
        boton.setText("Guardar"); 
        boton.setBounds(200, 200, 100, 30);  
        boton.addActionListener(this::actionPerformed_);      
        this.add(boton);
        boton1 = new JButton();  
        boton1.setText("Atras");   
        boton1.setBounds(50, 200, 100, 30);  
        boton1.addActionListener(this::actionPerformed);      
        this.add(boton1);
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            Ventana V = new Ventana();      
            V.setVisible(true);
        } catch (IOException ex) {
            Logger.getLogger(Agregar.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void actionPerformed_(ActionEvent e) {
        String pal=codTF.getText().trim()+" "+nomTF.getText().trim()+" "+lengTF.getText().trim();
        paises=paises.concat(pal);
       BufferedWriter bw;    
        try {
            bw = new BufferedWriter(new FileWriter(new File("src/Registro/registro.txt")));
            bw.write(paises);
            bw.close();
        } catch (IOException ex) {
            Logger.getLogger(Agregar.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }

    public static void main(String[] args) throws IOException {
        Agregar V = new Agregar();      
        V.setVisible(true);            
    }
}
