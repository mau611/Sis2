/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Registro;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


public class Ventana extends JFrame implements ActionListener {
    private JTextField caja;        
    private JButton boton;         
    private JButton boton1;     
    private String paises="";

    public Ventana() throws IOException {
        super();                    
        configurarVentana();        
        inicializarComponentes();   
    }

    private void configurarVentana() throws FileNotFoundException, IOException  {
        this.setTitle("Esta Es Una Ventana");                   
        this.setSize(410, 310);                                 
        this.setLocationRelativeTo(null);                       
        this.setLayout(null);                                   
        this.setResizable(false);                               
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        File fl = new File("src/Registro/registro.txt");
        FileReader f = new FileReader(fl);
        BufferedReader br = new BufferedReader(f);
        String paisS="";
            while((paisS=br.readLine())!=null){
                paises=paises.concat(paisS.toLowerCase().trim()).concat("\n");
            }
        
    }

    private void inicializarComponentes() {
        boton = new JButton();  
        boton.setText("Mostrar paises");   
        boton.setBounds(100, 50, 200, 30);  
        boton.addActionListener(this::actionPerformed_);      
        this.add(boton);
        boton1 = new JButton();  
        boton1.setText("Eliminar pais");   
        boton1.setBounds(100, 100, 200, 30);  
        boton1.addActionListener(this::actionPerformed);      
        this.add(boton1);
             
    }

    public void actionPerformed_(ActionEvent e){                      
        JOptionPane.showMessageDialog(this, paises);
    }
   
    

    public static void main(String[] args) throws IOException {
        Ventana V = new Ventana();      
        V.setVisible(true);             
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Agregar V = null;      
        try {
            V = new Agregar();
        } catch (IOException ex) {
            Logger.getLogger(Ventana.class.getName()).log(Level.SEVERE, null, ex);
        }
        V.setVisible(true);
    }
}
