package sisTrabajo;

public class Pais {
	protected String nombre;
	protected String codPais;
	protected  String idioma;
	
	public Pais(String nombre, String codPais, String idioma){
		this.nombre = nombre;
		this.codPais = codPais;
		this.idioma = idioma;
	}
	
}
